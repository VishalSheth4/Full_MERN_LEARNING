# FULL-MERN-AUTH-Boilerplate
MERN Authentication, Login, Register, verification email, Facebook, Google, Forget Password
Full Authentication  Login and Register with verification email and Facebook, Google Login with Forget and Reset Password using taliwind css
tutorial link: https://www.youtube.com/watch?v=y7yFXKsMD_U&fbclid=IwAR3QCM37B-Bi5SE27NcjRS07HBwff6hQwrBuLR4mDlpxu6MEXhWpRrdrOIM
![Github search](https://user-images.githubusercontent.com/25937925/77971844-11870400-72f0-11ea-8224-7e21a4f02a0a.png)
